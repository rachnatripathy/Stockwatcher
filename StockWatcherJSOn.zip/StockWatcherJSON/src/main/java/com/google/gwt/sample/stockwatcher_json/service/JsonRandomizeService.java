package com.google.gwt.sample.stockwatcher_json.service;

import java.util.Random;

import org.springframework.stereotype.Service;

@Service
public class JsonRandomizeService
{
	public Integer getRandomNumber()
	{
		Random rand = new Random();
		return rand.nextInt();
	}
}

package com.google.gwt.sample.stockwatcher_json.url;

public class URLConstants
{
	public static final String JSON_STOCK_PRICES = "jsonStockPrices.json";

	public static final String JSON_RANDOMIZE = "jsonRandomize.json";
}
